
  function writeChange(k){
	var buttons = document.getElementsByClassName('number');
	if (k !== -1){
		buttons[k].style.backgroundColor = "#e1e1e1";
		buttons[k].style.border = "1px solid #888888";
	} else {
		buttons[10].style.backgroundColor = "#e1e1e1";
		buttons[10].style.border = "1px solid #888888";
	}
	var pin = document.getElementsByClassName('.password');
	Array.prototype.forEach.call(pin, (element, index) => {
		if (k !== -1){
			if (element.value == ""){
				element.value = buttons[k].value;
			} 
		} else {
			for (var i=4; i>= 0; i--){
				if (pin[i].value !== ""){
					pin[i].value = "";
					break;//usciamo dal for se non cancella tutti i valori
				}
			}
		}
	});
	setTimeout(() => {
		if (k === -1){
			buttons[10].style.backgroundColor ="#E63241";
		} else{
			buttons[k].style.backgroundColor = "#1E96D7";
		}
	  }, 200);
  }

  function downSideUp(){
	const icon = document.getElementById('chevron');
	icon.classList.toggle('fa fa-chevron-up');
	alert('lilla');
  }
  
  function downStop(){
	const il = document.getElementById('downnMenu');
	il.style.visibility = 'visible';
	il.style.position = 'absolute';
	il.style.display = 'flex';
	il.style.border = '1px solid black';
  }


  function upSideDown(){
	const icon = document.getElementById('chevron');
	icon.classList.toggle('fa fa-chevron-down');
	alert('lello');
  }

  function ricordami(){
	alert('div visible');
	document.getElementById('dialog').style.visibility = visibile;
  }

  function abortRicorda(){
	alert('annulla la pressione del pulsante');
	document.getElementById('dialog').style.visibility = hidden;
  }

  function ricorda(){
	document.getElementById('ricorda').checked = true;
	document.getElementById("overlay").style.display = "none";
  }
  
  function disRicorda(){
	document.getElementById('ricorda').checked = false;
	document.getElementById("overlay").style.display = "none";
  }

  function write(k) {
	var indice = k-1;
	var buttons = document.getElementsByClassName('number');
		Array.prototype.forEach.call(buttons, (element, index) => {
			if(index == k){
				alert(element);
			}
		});
		console.log('hahahha');
  }

  function on() {
	if (document.getElementById('ricorda').checked ){
		document.getElementById("overlay").style.display = "block";
	}
  }

  function off() {
	document.getElementById("overlay").style.display = "none";
  }

  function randomNumber(){
	let number = [1,2,3,4,5,6,7,8,9,0];
	let text = [];

	while(text.length < 10){
	  let r = Math.floor(Math.random() * 10);
	  for (var i = 0; i < 10; i++){
		if (r === number[i]){
		  text.push(r);
		  number[i] = -1;
		}
	  }
	}
	text.push('C');
	var buttons = document.getElementsByClassName('number');
	Array.prototype.forEach.call(buttons, (element, index) => {
		element.value = text[index];
	});
  }


  function chevronUp(){
	document.getElementById('Gruppo').innerHTML = 'GRUPPO <i id="chevron" class="fa fa-chevron-up" aria-hidden="true"></i>';
  }

  function chevronDown(){
	document.getElementById('Gruppo').innerHTML = 'GRUPPO <i id="chevron" class="fa fa-chevron-down" aria-hidden="true"></i>';
  }

  function gruppoDiv(){
	var div = document.getElementById ('menuDown');
	if (div.innerHTML === ''){
		div.style.padding = '8px 16px';
		var k = "<table class='menuDownContent'> <tr> <td class='menuDownTd'>";
		div.innerHTML = k + " GRUPPO MEDIOLANUM <hr> </td> <td class='menuDownTd'> CONSULENZA <hr> </td> <td class='menuDownTd'> COMMUNITY <hr> </td> <td class='menuDownTd'> SOCIETÀ PRODOTTO <hr> </td> <td class='menuDownTd'> SOLIDARIETÀ <hr> </td> </tr> <tr> <td valign='top' class='menuDownTd'> <ul> <li> <a target='_blank' class='linkTable' href='https://www.bancamediolanum.it/'> Banca  Mediolanum</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.mediolanumcorporateuniversity.it/'>Mediolanum Mediolanum Corporate University</a> </li> <li> <a target='_blank' class='linkTable' href='http://www.mediolanumfiduciaria.it/'>Mediolanum Fiduciaria</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.mediolanuminvestmentbanking.it/'>Mediolanum Investment Banking</a> </li> <li> <a target='_blank' target='_blank' class='linkTable' href='https://www.bancomediolanum.es/'>Banco Mediolanum</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.prexta.it/'>Prexta S.p.A.</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.flowe.com/'>Flowe S.p.A. Società Benefit</a> </li> </ul> </td> <td valign='top' class='menuDownTd'> <ul> <li> <a target='_blank' class='linkTable' href='https://www.mediolanumprivatebanking.it/'> Private Banking</a> </li> <li> <a target='_blank' class='linkTable' href='http://www.familybanker.it/'>Family Banker</a> </li> </ul> </td> <td valign='top' class='menuDownTd'> <ul> <li> <a target='_blank' class='linkTable' href='https://www.centodieci.it/'>Centodieci</a> </li> </ul> </td> <td valign='top' class='menuDownTd'> <ul> <li> <a target='_blank' class='linkTable' href='https://www.mediolanumassicurazioni.it/'>Mediolanum Assicurazioni</a> </li> <li> <a target='_blank' class='linkTable' href='http://www.mediolanumgestionefondi.it/'>Mediolanum Gestione Fondi</a> </li> <li> <a target='_blank' class='linkTable' href='http://www.mediolanuminternationalfunds.it/'>Mediolanum International Funds</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.mediolanuminternationallife.it/'>Mediolanum International Life</a> </li> <li> <a target='_blank' class='linkTable' href='https://www.mediolanumvita.it/'>Mediolanum Vita</a> </li> </ul> </td> <td valign='top' class='menuDownTd'> <ul> <li> <a target='_blank' class='linkTable' href='https://www.fondazionemediolanum.it/'>Fondazione Mediolanum Onlus</a> </li> </ul> </td> </tr> </table>";
	} else {
		div.style.padding = '0';
		div.innerHTML = '';
	}
  }


