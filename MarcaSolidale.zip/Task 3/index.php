<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Marca Solidale</title>
  <link rel="stylesheet" href="CSS/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Titillium Web'>
</head>
<body>
  <div id="container">
    <div>
      <img src="Img/marcasolidale.png" alt="logo" id="Logo">
    </div>
    <form action="#" method="post">
      <div id="loginDiv">
        <input class="inputField" type="text" name="login" id="login" onfocus="moveLabelLog()" onblur="resetLabel(this)" required>
        <label id="label1" for="login">Email/numero tessera</label>
      </div>
      <div id="passwordDiv">
        <input class="inputField" id="password" name="password" type="password" oninput="moveLabelPass()" onblur="resetLabel(this)" required> 
        <button type="button" id="toggle-password" onclick="togglePasswordVisibility()"> 
          <i id="toggleIcon" class="fa fa-eye"></i> 
        </button> 
        <label id="label2" for="password">Password</label>
      </div>
      <div>
        <input type="submit" name="submit" id="submit" value="Login">
		<?php
      
      		include "redirect.php";
      	?>
      </div>
    </form>
    <div>
      <a id="link1" href="https://soci.marcasolidale.it/password-dimenticata">Password dimenticata?</a>
    </div>
    <br>
    <div>
      Sei socio ma non hai un account 
      <br>
      <a id="link2" href="https://soci.marcasolidale.it/registrati?c=marcasolidale">  Registra il tuo account</a>
    </div>
  </div>
  <script src="js/script.js"></script>
</body>
</html>