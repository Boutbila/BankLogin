function togglePasswordVisibility() { 
	var toggle = document.getElementById("toggleIcon");
	var passwordInput = document.getElementById('password'); 
	if (passwordInput.type === "password") { 
	  passwordInput.type = "text"; 
	  toggle.classList.remove('fa-eye'); 
	  toggle.classList.add('fa-eye-slash'); 
	} else { 
	  passwordInput.type = "password"; 
	  toggle.classList.remove('fa-eye-slash'); 
	  toggle.classList.add('fa-eye'); 
	} 
  }

  function moveLabelLog() {

	  var input = document.getElementById('login');
	  var parentDiv = input.parentNode;
	  var label = parentDiv.querySelector('label');

	  parentDiv.style.position = 'relative';

	  label.style.position = 'absolute';
	  label.style.top = '1.25em';
	  label.style.left = '16px';
	  label.style.fontSize = '14px';
	  label.style.color = '#9d2235';

	  

	  
  }
  
  function resetLabel(input){
	  var parentDiv = input.parentNode;
		var label = parentDiv.querySelector('label');
		label.style.color = '#bbbbbb';
	  if (input.value == "") {
		  parentDiv.style.position = '';

		  label.style.position = '';
		  label.style.top = '';
		  label.style.left = '';
		  label.style.fontSize = '';

		  
	  }
  }

  function moveLabelPass() {
	var input = document.getElementById('password');
	var parentDiv = input.parentNode;
	var label = parentDiv.querySelector('label');

	if (input.value !== "") {
	  parentDiv.style.position = 'relative';

	  label.style.position = 'absolute';
	  label.style.top = '1.25em';
	  label.style.left = '16px';
	  label.style.fontSize = '14px';
	  label.style.color = '#9d2235';

	  
	} else {
	  parentDiv.style.position = '';

	  label.style.position = '';
	  label.style.top = '';
	  label.style.left = '';
	  label.style.fontSize = '';
	  label.style.color = '';

	  
	}
  }