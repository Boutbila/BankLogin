<?php
 
  if(isset($_POST["submit"])) {
      header("location:https://www.bancadellamarca.it");
      
    
  }
?>